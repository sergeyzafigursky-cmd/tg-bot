# Telegram Bot (Praca Polska)

Простий Telegram-бот-візитка для каналу @praca_polska_europa.

## Функції
- Кнопка для переходу на основний канал
- Кнопка для контакту з адміністратором

## Як використовувати
1. Створи нового бота у @BotFather та отримай API_TOKEN.
2. Додай API_TOKEN у Render → Environment Variables.
3. Завантаж цей код у GitHub.
4. Підключи Render → New Web Service:
   - Build command: pip install -r requirements.txt
   - Start command: python bot.py
5. Бот працює 24/7 🚀
